﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions{

	[ActionCategory("PolyNav")]
	[Tooltip("Set destination for a PolyNav Agent to a target vector position")]
	public class MoveToPosition : FsmStateAction {

		[RequiredField]
		[CheckForComponent(typeof(PolyNavAgent))]
		public FsmOwnerDefault agent;
		public FsmVector2 targetPosition;
		public FsmEvent invalidEvent;
		public FsmEvent reachEvent;

		public override void Reset(){
			agent = null;
			targetPosition = null;
		}

		public override void OnEnter(){

			var go = Fsm.GetOwnerDefaultTarget(agent);
			if (go == null){
				Finish();
				return;
			}

			if (!go.GetComponent<PolyNavAgent>().SetDestination(targetPosition.Value, Callback)){
				Fsm.Event(invalidEvent);
				Finish();
			}
		}

		void Callback(bool isValid){

			Fsm.Event(isValid? reachEvent : invalidEvent);
			Finish();
		}

		public override void OnExit(){

			Fsm.GetOwnerDefaultTarget(agent).GetComponent<PolyNavAgent>().Stop();
		}
	}
}