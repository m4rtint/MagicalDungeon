﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions{

	[ActionCategory("PolyNav")]
	[Tooltip("Set destination for a PolyNav Agent to a target gameObject position")]
	public class MoveToGameObject : FsmStateAction {

		[RequiredField]
		[CheckForComponent(typeof(PolyNavAgent))]
		public FsmOwnerDefault agent;
		public FsmGameObject targetGameObject;
		public FsmEvent invalidEvent;
		public FsmEvent reachEvent;

		public override void Reset(){
			agent = null;
			targetGameObject = null;
		}

		public override void OnEnter(){

			var go = Fsm.GetOwnerDefaultTarget(agent);
			if (go == null){
				Finish();
				return;
			}

			if (!go.GetComponent<PolyNavAgent>().SetDestination(targetGameObject.Value.transform.position, Callback)){
				Fsm.Event(invalidEvent);
				Finish();
			}
		}

		void Callback(bool isValid){

			Fsm.Event(isValid? reachEvent : invalidEvent);
			Finish();
		}

		public override void OnExit(){

			Fsm.GetOwnerDefaultTarget(agent).GetComponent<PolyNavAgent>().Stop();
		}
	}
}