﻿using UnityEngine;
using NodeCanvas.Variables;

namespace NodeCanvas.Conditions{

	[Name("Has Path")]
	[Category("PolyNav")]
	[AgentType(typeof(PolyNavAgent))]
	public class PolyNavHasPath : ConditionTask {

		protected override string info{
			get {return string.Format("{0} has path", agentInfo);}
		}

		protected override bool OnCheck(){

			return (agent as PolyNavAgent).hasPath;
		}
	}
}