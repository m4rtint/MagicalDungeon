﻿using UnityEngine;
using NodeCanvas.Variables;

namespace NodeCanvas.Conditions{

	[Name("Check Valid Point")]
	[Category("PolyNav")]
	public class PolyNavCheckValidPoint : ConditionTask {

		public BBVector position;

		protected override string info{
			get {return string.Format("{0} is valid", position);}
		}

		protected override bool OnCheck(){

			if (!PolyNav2D.current)
				return false;
			return PolyNav2D.current.PointIsValid(position.value);
		}
	}
}