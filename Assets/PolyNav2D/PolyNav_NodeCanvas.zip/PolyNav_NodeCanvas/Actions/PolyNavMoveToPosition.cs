﻿using UnityEngine;
using System.Collections;
using NodeCanvas.Variables;

namespace NodeCanvas.Actions{

	[Name("Go To Position")]
	[Category("PolyNav")]
	[AgentType(typeof(PolyNavAgent))]
	public class PolyNavMoveToPosition : ActionTask {

		public BBVector targetPosition;
		public BBFloat speed = new BBFloat{value = 4};

		PolyNavAgent navAgent{
			get {return agent as PolyNavAgent;}
		}

		protected override string info{
			get {return string.Format("GoTo {0}", targetPosition);}
		}

		protected override void OnExecute(){

			navAgent.maxSpeed = speed.value;
			if (! navAgent.SetDestination(targetPosition.value, delegate(bool canGo){ EndAction(canGo); } ))
				EndAction(false);
		}

		protected override void OnStop(){
			navAgent.Stop();
		}
	}
}