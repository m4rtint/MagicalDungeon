﻿using UnityEngine;
using System.Collections;
using NodeCanvas.Variables;

namespace NodeCanvas.Actions{

	[Name("Stop Moving")]
	[Category("PolyNav")]
	[AgentType(typeof(PolyNavAgent))]
	public class PolyNavStopMoving : ActionTask {

		PolyNavAgent navAgent{
			get {return agent as PolyNavAgent;}
		}

		protected override void OnExecute(){

			navAgent.Stop();
			EndAction(true);
		}
	}
}