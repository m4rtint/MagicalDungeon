﻿using UnityEngine;
using System.Collections;
using NodeCanvas.Variables;

namespace NodeCanvas.Actions{

	[Name("Go To GameObject")]
	[Category("PolyNav")]
	[AgentType(typeof(PolyNavAgent))]
	public class PolyNavMoveToGameObject : ActionTask {

		[RequiredField]
		public BBGameObject targetObject;
		public BBFloat speed = new BBFloat{value = 4};

		PolyNavAgent navAgent{
			get {return agent as PolyNavAgent;}
		}

		protected override string info{
			get {return string.Format("GoTo {0}", targetObject);}
		}

		protected override void OnExecute(){

			navAgent.maxSpeed = speed.value;
			if (! navAgent.SetDestination(targetObject.value.transform.position, delegate(bool canGo){ EndAction(canGo); } ))
				EndAction(false);
		}

		protected override void OnStop(){
			navAgent.Stop();
		}
	}
}