﻿using UnityEngine;
using System.Collections.Generic;
using NodeCanvas.Variables;

namespace NodeCanvas.Actions{

	[Name("Calculate Path")]
	[Category("PolyNav")]
	[Description("Calculate a path and return success if path exists or failure if not")]
	public class PolyNavCalculatePath : ActionTask {

		public BBVector from;
		public BBVector to;

		protected override string info{
			get {return string.Format("CalcPath {0} - {1}", from, to);}
		}

		protected override void OnExecute(){

			if (!PolyNav2D.current){
				EndAction(false);
				return;
			}

			PolyNav2D.current.FindPath(from.value, to.value, PathReady);
		}

		void PathReady(List<Vector2> path){

			EndAction(path != null && path.Count != 0);
		}
	}
}